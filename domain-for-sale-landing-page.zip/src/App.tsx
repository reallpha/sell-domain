export default function App() {
  return (
    <main className="relative flex min-h-screen items-center justify-center overflow-hidden bg-[#08111f] px-4 py-8 text-white sm:px-6 sm:py-12" dir="rtl">
      {/* Soft light spots keep the glass effect visible without adding visual clutter. */}
      <div className="pointer-events-none absolute -right-32 -top-32 h-80 w-80 rounded-full bg-blue-500/20 blur-3xl" />
      <div className="pointer-events-none absolute -bottom-40 -left-24 h-96 w-96 rounded-full bg-cyan-400/10 blur-3xl" />

      <section className="glass-panel relative w-full max-w-xl overflow-hidden rounded-3xl px-5 py-8 text-center sm:px-10 sm:py-12">
        <div className="mx-auto mb-6 flex h-14 w-14 items-center justify-center rounded-2xl border border-blue-300/20 bg-blue-400/10 text-blue-300">
          <svg className="h-7 w-7" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.7" aria-hidden="true">
            <circle cx="12" cy="12" r="9" />
            <path d="M3 12h18M12 3c2.3 2.4 3.4 5.4 3.4 9s-1.1 6.6-3.4 9c-2.3-2.4-3.4-5.4-3.4-9S9.7 5.4 12 3Z" />
          </svg>
        </div>

        <p className="mb-3 text-sm font-medium text-blue-300">فرصت یک انتخاب خاص</p>
        <h1 className="text-3xl font-extrabold leading-tight tracking-tight sm:text-5xl">
          این دامنه برای فروش است
        </h1>
        <p className="mx-auto mt-5 max-w-md text-sm leading-7 text-slate-300 sm:text-base">
          برای اطلاع از قیمت و خرید دامنه، همین حالا با ما تماس بگیرید.
        </p>

        <div className="mt-8 grid gap-3 sm:grid-cols-2">
          <a
            href="tel:09032350099"
            className="button-primary inline-flex min-h-14 items-center justify-center gap-3 rounded-2xl px-5 py-4 text-base font-bold sm:text-lg"
          >
            <svg className="h-5 w-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" aria-hidden="true">
              <path strokeLinecap="round" strokeLinejoin="round" d="M5 4h3l2 5-2 1.5a12 12 0 0 0 5.5 5.5L15 14l5 2v3a1 1 0 0 1-1 1C10.7 20 4 13.3 4 5a1 1 0 0 1 1-1Z" />
            </svg>
            <span dir="ltr">0903 235 0099</span>
          </a>

          <a
            href="https://wa.me/989032350099?text=سلام، به خرید این دامنه علاقه‌مند هستم."
            target="_blank"
            rel="noopener noreferrer"
            className="button-secondary inline-flex min-h-14 items-center justify-center gap-3 rounded-2xl px-5 py-4 text-base font-semibold sm:text-lg"
          >
            <svg className="h-5 w-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" aria-hidden="true">
              <path strokeLinecap="round" strokeLinejoin="round" d="M20 11.5a8 8 0 0 1-11.8 7L4 20l1.5-4.1A8 8 0 1 1 20 11.5Z" />
              <path strokeLinecap="round" strokeLinejoin="round" d="M9 8.5c.2 2 1.4 3.3 3.5 4.2.6.2 1-.1 1.5-.8l.4-.6" />
            </svg>
            <span>پیام در واتساپ</span>
          </a>
        </div>

        <div className="mt-7 flex items-center justify-center gap-2 text-xs text-slate-400">
          <span className="h-2 w-2 rounded-full bg-emerald-400 shadow-[0_0_12px_rgba(52,211,153,0.8)]" />
          پاسخ‌گویی سریع برای خرید
        </div>
      </section>
    </main>
  );
}
